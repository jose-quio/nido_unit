package com.example.departament;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepartamentApplication {

	public static void main(String[] args) {
		SpringApplication.run(DepartamentApplication.class, args);
	}

}
